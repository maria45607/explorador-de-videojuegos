const API_KEY = 'dcdfa9c8d74a4f80b3b5851e163de53f';
const BASE_URL = 'https://api.rawg.io/api/games';


const gameCardsWrapper = document.getElementById('game-cards-wrapper');
const paginationControls = document.getElementById('pagination-controls');


const GAMES_PER_PAGE = 10;
let allGames = [];
let currentPage = 1;


const gameCustomLinks = new Map([

    [22513, 'https://www.exito.com/videojuego-uncharted-2-among-thieves-playstation-3-100128136-mp/p'], // Uncharted 2: Among Thieves
    [516111, 'https://store.steampowered.com/agecheck/app/1328670/'], // Mass Effect: Legendary Edition
    [20760, 'https://store.steampowered.com/agecheck/app/292120/?l=spanish'], // FINAL FANTASY XIII
    [58585, 'https://store.steampowered.com/agecheck/app/1151340/?l=spanish'], // Fallout 76
    [3251, 'https://www.xbox.com/es-CL/games/store/f1-2015/brq7qhzdwv1c'], // F1 2015
    [17925, 'https://store.steampowered.com/app/288470/Fable_Anniversary/'], // Fable Anniversary
    [137, 'https://store.steampowered.com/app/1238000/Edicin_Deluxe_de_Mass_Effect_Andromeda/'], // Mass Effect: Andromeda
    [2239, 'https://store.steampowered.com/app/423230/Furi/'], // Furi
    [4744, 'https://store.steampowered.com/app/19980/Prince_of_Persia/'], // Prince of Persia (2008)
    [2354, 'https://store.steampowered.com/app/1233570/Mirrors_Edge_Catalyst/'], // Mirror's Edge Catalyst
    [123, 'https://store.steampowered.com/app/475150/Titan_Quest_Anniversary_Edition/'], // Titan Quest
    [401805, 'https://www.xbox.com/es-MX/games/store/genshin-impact/9N7TFFRRZCC9/0010'], // Genshin Impact
    [13469, 'https://store.steampowered.com/agecheck/app/4570/'], // Warhammer 40,000: Dawn of War - Game of the Year Edition
    [28261, 'https://store.steampowered.com/agecheck/app/41000/'], // Serious Sam HD: The First Encounter
    [10049, 'https://store.steampowered.com/agecheck/app/6900/'], // Hitman: Codename 47
    [4923, 'https://store.steampowered.com/agecheck/app/10150/?l=spanish'], // Prototype
    [3772, 'https://store.steampowered.com/app/235210/STRIDER/?l=spanish'], // Strider
    [19458, 'https://store.steampowered.com/agecheck/app/3017860/'], // DOOM
    [9465, 'https://store.steampowered.com/app/219990/Grim_Dawn/'], // Grim Dawn
    [19309, 'https://store.steampowered.com/app/3590/Plants_vs_Zombies_GOTY_Edition/?l=spanish'], // Plants vs. Zombies GOTY Edition
    [14990, 'https://store.steampowered.com/agecheck/app/211160/'], // Viking: Battle for Asgard
    [3748, 'https://store.steampowered.com/app/252410/SteamWorld_Dig/?l=spanish'], // SteamWorld Dig
    [323065, 'https://store.steampowered.com/agecheck/app/2000950/'], // Call of Duty: Modern Warfare (2019)
    [29173, 'https://store.steampowered.com/agecheck/app/614570/'], // Dishonored: Death of the Outsider
    [2913, 'https://store.steampowered.com/app/237990/The_Banner_Saga/?l=spanish'], // The Banner Saga
    [2845, 'https://store.steampowered.com/app/247080/Crypt_of_the_NecroDancer/?l=spanish'], // Crypt of the NecroDancer
    [722, 'https://store.steampowered.com/app/1407200/World_of_Tanks/'], // World of Tanks
    [19284, 'https://store.steampowered.com/agecheck/app/38420/'], // Fallout Tactics: Brotherhood of Steel
    [7485, 'https://store.steampowered.com/app/359320/Elite_Dangerous/'], // Elite Dangerous
    [50677, 'https://store.steampowered.com/app/690040/SUPERHOT_MIND_CONTROL_DELETE/'], // Superhot: Mind Control Delete
   
]);



/**

 * @param {number} page
 * @param {number} pageSize 
 * @returns {Promise<Array>} 
 */
async function fetchGames(page, pageSize) {
    try {
        gameCardsWrapper.innerHTML = '<p>Cargando videojuegos...</p>';
        const response = await fetch(`${BASE_URL}?key=${API_KEY}&page=${page}&page_size=${pageSize}`);
        if (!response.ok) {
            throw new Error(`Error al cargar los videojuegos: ${response.statusText}`);
        }
        const data = await response.json();
        return data.results;
    } catch (error) {
        console.error("Error al obtener los videojuegos:", error);
        gameCardsWrapper.innerHTML = '<p style="color: red;">Error al cargar los videojuegos. Por favor, intenta de nuevo más tarde o revisa tu API Key.</p>';
        return [];
    }
}

/**
 * 
 * @param {Object} game 
 * @returns {HTMLElement} 
 */
function createGameCard(game) {
    const card = document.createElement('div');
    card.classList.add('game-card');

   
    const img = document.createElement('img');
    img.src = game.background_image || 'https://via.placeholder.com/400x200?text=No+Image';
    img.alt = game.name;
    card.appendChild(img);

    const content = document.createElement('div');
    content.classList.add('card-content');

   
    const title = document.createElement('h3');
    title.textContent = game.name;
    content.appendChild(title);

    
    const released = document.createElement('p');
    released.innerHTML = `<strong>Lanzamiento:</strong> ${game.released || 'N/A'}`;
    content.appendChild(released);

    
    const updated = document.createElement('p');
    const lastUpdated = new Date(game.updated).toLocaleDateString('es-ES', {
        year: 'numeric',
        month: 'long',
        day: 'numeric'
    });
    updated.innerHTML = `<strong>Última actualización:</strong> ${lastUpdated}`;
    content.appendChild(updated);

   
    if (game.platforms && game.platforms.length > 0) {
        const platformsLabel = document.createElement('p');
        platformsLabel.innerHTML = '<strong>Plataformas:</strong>';
        content.appendChild(platformsLabel);

        const platformsList = document.createElement('ul');
        game.platforms.forEach(platformInfo => {
            const platformName = platformInfo.platform?.name;
            if (platformName) {
                const platformItem = document.createElement('li');
                platformItem.textContent = platformName;
                platformsList.appendChild(platformItem);
            }
        });
        content.appendChild(platformsList);
    } else {
        const noPlatforms = document.createElement('p');
        noPlatforms.innerHTML = '<strong>Plataformas:</strong> N/A';
        content.appendChild(noPlatforms);
    }

 
    const storesSection = document.createElement('div');
    storesSection.classList.add('stores-list');
    storesSection.innerHTML = '<h4>Tiendas disponibles:</h4><p class="loading-stores">Cargando tiendas...</p>';
    content.appendChild(storesSection);

   
    card.appendChild(content);

    return card;
}


/**
 * 
 * @param {Array} gamesToRender 
 */
function renderGameCards(gamesToRender) {
    gameCardsWrapper.innerHTML = '';
    if (gamesToRender.length === 0) {
        gameCardsWrapper.innerHTML = '<p>No se encontraron videojuegos para mostrar.</p>';
        return;
    }
    gamesToRender.forEach(game => {
        const card = createGameCard(game);
        gameCardsWrapper.appendChild(card);
       
        const customLink = gameCustomLinks.get(game.id);
        fetchGameStores(game.id, card, customLink); 
    });
}

/**
 * 
 * @param {number} gameId 
 * @param {HTMLElement} cardElement 
 * @param {string} [customGameLink]
 */
async function fetchGameStores(gameId, cardElement, customGameLink = null) {
    const storesSection = cardElement.querySelector('.stores-list');
    if (!storesSection) return;

    storesSection.innerHTML = '<h4>Tiendas disponibles:</h4>'; // Limpia el mensaje de carga

    try {
        const response = await fetch(`${BASE_URL}/${gameId}/stores?key=${API_KEY}`);
        if (!response.ok) {
            throw new Error(`Error al cargar las tiendas: ${response.statusText}`);
        }
        const data = await response.json();
        const stores = data.results;

        let storesRendered = 0; 

        if (customGameLink) {
            const customLinkElement = document.createElement('a');
            customLinkElement.href = customGameLink;
            customLinkElement.textContent = 'Disponible Aqui'; 
            customLinkElement.target = '_blank';
            customLinkElement.rel = 'noopener noreferrer';
            storesSection.appendChild(customLinkElement);
            storesRendered++;
        }
        // =========================================================

        if (stores && stores.length > 0) {
            stores.forEach(storeInfo => {
                const storeUrl = storeInfo.url;
                const storeName = storeInfo.store?.name;

                if (storeUrl && storeName) {
                    const storeLink = document.createElement('a');
                    storeLink.href = storeUrl;
                    storeLink.textContent = storeName;
                    storeLink.target = '_blank';
                    storeLink.rel = 'noopener noreferrer';
                    storesSection.appendChild(storeLink);
                    storesRendered++;
                }
            });
        }

       
        if (storesRendered === 0) {
            const noStores = document.createElement('p');
            noStores.textContent = 'No hay tiendas disponibles.';
            storesSection.appendChild(noStores);
        }

    } catch (error) {
        console.error(`Error fetching stores for game ${gameId}:`, error);
        const errorMsg = document.createElement('p');
        errorMsg.textContent = 'Error al cargar las tiendas.';
        errorMsg.style.color = 'red';
        storesSection.appendChild(errorMsg);
    }
}



function setupPaginationControls() {
    paginationControls.innerHTML = '';

    const totalPages = Math.ceil(allGames.length / GAMES_PER_PAGE);

    const prevButton = document.createElement('button');
    prevButton.textContent = 'Anterior';
    prevButton.id = 'prevPage';
    prevButton.disabled = currentPage === 1;
    prevButton.addEventListener('click', () => {
        if (currentPage > 1) {
            currentPage--;
            displayGamesForCurrentPage();
        }
    });
    paginationControls.appendChild(prevButton);

    const pageInfo = document.createElement('span');
    pageInfo.id = 'pageInfo';
    pageInfo.textContent = `Página ${currentPage} de ${totalPages}`;
    paginationControls.appendChild(pageInfo);

    const nextButton = document.createElement('button');
    nextButton.textContent = 'Siguiente';
    nextButton.id = 'nextPage';
    nextButton.disabled = currentPage === totalPages;
    nextButton.addEventListener('click', () => {
        if (currentPage < totalPages) {
            currentPage++;
            displayGamesForCurrentPage();
        }
    });
    paginationControls.appendChild(nextButton);
}


function displayGamesForCurrentPage() {
    const startIndex = (currentPage - 1) * GAMES_PER_PAGE;
    const endIndex = startIndex + GAMES_PER_PAGE;
    const gamesToDisplay = allGames.slice(startIndex, endIndex);

    renderGameCards(gamesToDisplay);
    updatePaginationControls();

    window.location.hash = `page=${currentPage}`;
}


function updatePaginationControls() {
    const totalPages = Math.ceil(allGames.length / GAMES_PER_PAGE);
    document.getElementById('prevPage').disabled = currentPage === 1;
    document.getElementById('nextPage').disabled = currentPage === totalPages;
    document.getElementById('pageInfo').textContent = `Página ${currentPage} de ${totalPages}`;
}

/**
 * 
 * @returns {number} 
 */
function getPageFromHash() {
    const hash = window.location.hash;
    if (hash) {
        const match = hash.match(/#page=(\d+)/);
        if (match && match[1]) {
            const pageNum = parseInt(match[1], 10);
            const totalPages = Math.ceil(allGames.length / GAMES_PER_PAGE);
            if (pageNum >= 1 && pageNum <= totalPages) {
                return pageNum;
            }
        }
    }
    return 1;
}



async function init() {
    allGames = await fetchGames(19, 30); 

    if (allGames.length > 0) {
        setupPaginationControls();
        currentPage = getPageFromHash();
        displayGamesForCurrentPage();
    }
}

window.addEventListener('hashchange', () => {
    if (allGames.length > 0) {
        const newPage = getPageFromHash();
        if (newPage !== currentPage) {
            currentPage = newPage;
            displayGamesForCurrentPage();
        }
    }
});


document.addEventListener('DOMContentLoaded', init);